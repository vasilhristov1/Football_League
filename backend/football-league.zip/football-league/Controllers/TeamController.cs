using AutoMapper;
using football_league.Data.ViewModels;
using football_league.Managers.Abstractions;
using football_league.Models;
using football_league.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace football_league.Controllers;

using TeamsResponse = PaginatedResponse<TeamResultModel, TeamPaginationMetadata>;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class TeamController(ITeamManager teamManager, IMapper mapper) : ControllerBase
{
    private readonly ITeamManager _teamManager = teamManager;
    private readonly IMapper _mapper = mapper;

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] TeamQuery queryParams)
    {
        return Ok(_mapper.Map<TeamsResponse>(await _teamManager.GetAllTeamsAsync(queryParams)));
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id) =>
        await _teamManager.GetTeamByIdAsync(id) is Team team ? Ok(team) : NotFound();

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateTeamModel dto)
    {
        var team = new Team { Name = dto.Name };
        var result = await _teamManager.CreateTeamAsync(team);
        return CreatedAtAction(nameof(Get), new { id = result.Id }, result);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] CreateTeamModel dto)
    {
        var team = new Team { Name = dto.Name };
        var result = await _teamManager.UpdateTeamAsync(id, team);
        return result != null ? Ok(result) : NotFound();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id) =>
        await _teamManager.DeleteTeamAsync(id) ? Ok() : NotFound();

    [HttpGet("ranking")]
    public async Task<IActionResult> GetRanking() =>
        Ok(await _teamManager.GetRankingsAsync());
}