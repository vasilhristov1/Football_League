using AutoMapper;
using football_league.Data.ViewModels;
using football_league.Managers.Abstractions;
using football_league.Models;
using football_league.Models.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace football_league.Controllers;

using MatchesResponse = PaginatedResponse<MatchResultModel, MatchPaginationMetadata>;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class MatchController(IMatchManager matchManager, IMapper mapper) : ControllerBase
{
    private readonly IMatchManager _matchManager = matchManager;
    private readonly IMapper _mapper = mapper;

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] MatchQuery queryParams)
    {
        return Ok(_mapper.Map<MatchesResponse>(await _matchManager.GetAllMatchesAsync(queryParams)));
    }

    [HttpPost]
    public async Task<IActionResult> CreateMatch([FromBody] CreateMatchModel dto)
    {
        if (dto.HomeTeamId == dto.AwayTeamId)
            return BadRequest("A team cannot play against itself.");

        var match = new Match
        {
            HomeTeamId = dto.HomeTeamId,
            AwayTeamId = dto.AwayTeamId,
            HomeScore = dto.HomeScore,
            AwayScore = dto.AwayScore,
            PlayedAt = dto.DatePlayed
        };

        await _matchManager.CreateMatchAsync(match);

        // Optional: Update Points (can be done by decorator)
        return Created("", match);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteMatch(int id)
    {
        return await _matchManager.DeleteMatchAsync(id) ? Ok() : NotFound();
    }
}