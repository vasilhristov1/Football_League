namespace football_league.Models.DTOs;

public class CreateTeamModel
{
    public string Name { get; set; }
}